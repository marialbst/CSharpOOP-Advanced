﻿namespace _07.FoodShortage.Interfaces
{
    public interface ISocietyMember
    {
        string Id { get; }
    }
}