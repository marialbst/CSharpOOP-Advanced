﻿namespace _07.FoodShortage.Interfaces
{
    public interface IBuyer
    {
        int Food { get; }
        void BuyFood();
    }
}
