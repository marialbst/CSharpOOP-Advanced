﻿namespace _07.FoodShortage.Interfaces
{
    public interface IHuman : IBuyer
    {
        int Age { get; }
        string Name { get;}
    }
}
