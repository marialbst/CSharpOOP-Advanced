﻿namespace _07.FoodShortage.Interfaces
{
    public interface IBirthdate
    {
        string Birthdate { get; }
    }
}
