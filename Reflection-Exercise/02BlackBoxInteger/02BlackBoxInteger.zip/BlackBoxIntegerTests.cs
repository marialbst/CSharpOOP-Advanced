﻿namespace _02BlackBoxInteger
{
    using Core;
    using System;

    class BlackBoxIntegerTests
    {
        static void Main(string[] args)
        {
            //TODO write your solution of Problem 2. Black Box Integer here
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
